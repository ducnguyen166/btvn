<?php

    for($i=0;$i<=100;$i++){
        if($i%4==0){
            echo "$i<br/>";
        }    
}
?>