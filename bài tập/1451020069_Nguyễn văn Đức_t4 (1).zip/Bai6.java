import java.util.Scanner;

public class Bai6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Moi ban nhap vao 1 chuoi: ");
        String s = scanner.nextLine();
        int tongSoDauCach = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') {
                tongSoDauCach++;
            }
        }
        System.out.println(s + " co tong so " + tongSoDauCach + " dau cach!");
    }
}
