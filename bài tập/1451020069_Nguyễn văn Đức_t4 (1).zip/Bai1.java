import java.util.Arrays;
import java.util.Scanner;

public class Bai1 {
    public static void main(String[] args) {
        int n;
        System.out.print("Moi ban nhap vao mot so nguyen: ");
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        System.out.println("Tri tuyet doi cua " + n + " la: " + Math.abs(n));
    }
}
