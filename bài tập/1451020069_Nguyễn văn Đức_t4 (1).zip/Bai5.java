import java.util.Scanner;

public class Bai5 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Moi ban nhap vao 1 so nguyen: ");
        int n = scanner.nextInt();

        int[] a = new int[n];
        System.out.println("Moi ban nhap vao mang:");
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }

        int tong = 0;
        System.out.print("Mang vua nhap la: ");
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + "\t");
            tong += a[i];
        }

        System.out.println("\nTong cac phan tu cua mang la: " + tong);
    }
}
