import java.util.Scanner;

public class bai2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Moi ban nhap vao chieu cao cua An: ");
        int an = scanner.nextInt();
        System.out.print("Moi ban nhap vao chieu cao cua Hoa: ");
        int hoa = scanner.nextInt();
        System.out.print("Moi ban nhap vao chieu cao cua Bac: ");
        int bac = scanner.nextInt();

        // tim nguoi cao nhat
        int max = an;
        if (max < hoa) {
            max = hoa;
        }
        if (max < bac) {
            max = bac;
        }
        System.out.println("Nguoi cao nhat la " + max);

        // tim nguoi thap nhat
        int min = an;
        if (min > hoa) {
            min = hoa;
        }
        if (min > bac) {
            min = bac;
        }
        System.out.println("Nguoi thap nhat la " + min);
    }

}
