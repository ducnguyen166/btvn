import java.util.Scanner;

public class Bai3 {

    public static void main(String[] args) {
        int n, tong = 0;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Moi ban nhap vao so nguyen n: ");
        n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                tong += i;
            }
        }
        System.out.println("Tong cac so chan tu 1 - " + n + " =: " + tong);
    }
}
