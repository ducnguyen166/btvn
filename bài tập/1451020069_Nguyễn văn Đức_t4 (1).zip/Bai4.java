import java.util.Scanner;

public class Bai4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Moi ban nhap vao so n(10<=n<=999): ");
        int n = scanner.nextInt();
        int thuong = n;
        int tongCacChuSo = 0;
        System.out.print("Cac chu so cua so " + n + "la: ");
        do {
            int du = thuong % 10;
            thuong /= 10;
            tongCacChuSo += du;
            System.out.print(du + "\t");
        } while (thuong != 0);
        System.out.println();

        if (n % tongCacChuSo == 0) {
            System.out.println(n + " la so dac biet!");
        } else {
            System.out.println(n + " khong phai la so dac biet!");
        }
    }
}
