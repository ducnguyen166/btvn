<html>
    <head>
        <title>Danh sách tài khoản</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db = "csdlphp";

            $conn = mysqli_connect($servername, $username, $password, $db);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $keyword = $_GET['keyword'];

            $select_query = "SELECT MaTaiKhoan, ThuDienTu FROM tbltaikhoan WHERE ThuDienTu LIKE '" . $keyword . "%' LIMIT 0,15";
            $result = mysqli_query($conn, $select_query); 
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
            <input type="text" name="keyword" value="<?php echo $keyword; ?>"/>
            <input type="submit" value="Tìm kiếm"/>
        </form>
        <br/>
        <table>
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Thư điện tử</td>
                </tr>
            </thead>
            <?php 
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                        <tr>
                            <td><a href="chitiettk.php?id=<?php echo $row['MaTaiKhoan']; ?>"><?php echo $row['MaTaiKhoan']; ?></a>
                        </td>
                            <td><a href="chitiettk.php?id=<?php echo $row['MaTaiKhoan']; ?>"><?php echo $row['ThuDienTu']; ?></a></td>
                        </tr>
                        <?php
                    }
                }
                else {
                    
                }
                mysqli_close($conn);
            ?>
        </table>
    </body>
</html>