<html>
    <head>
        <title>Chi tiết tài khoản</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $db = "csdlphp";

            $conn = mysqli_connect($servername, $username, $password, $db);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $id = $_GET['id'];

            $select_query = "SELECT MaTaiKhoan, ThuDienTu FROM tbltaikhoan WHERE MaTaiKhoan=" . $id;
            $result = mysqli_query($conn, $select_query); 
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                echo "Tài khoản có mã: " .  $row['MaTaiKhoan'] . ", thư điện tử: " . $row['ThuDienTu'];
            }
        ?>
    </body>
</html>