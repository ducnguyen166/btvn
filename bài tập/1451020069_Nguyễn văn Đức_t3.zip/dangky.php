<html>
    <head>
        <title>Xử lý đăng ký</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <?php
            function kiemTraDuLieu($dulieu) {
                $dulieu = trim($dulieu);
                $dulieu = stripslashes($dulieu);
                $dulieu = htmlspecialchars($dulieu);
                return $dulieu;
            }
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $kiemtraFlag = true;
                $email = $password = $repassword = '';
                if (empty($_POST['email'])) {
                    $kiemtraFlag = false;
                }
                else {
                    $email = kiemTraDuLieu($_POST['email']);
                }
                if (empty($_POST['password'])) {
                    $kiemtraFlag = false;
                }
                else {
                    $password = kiemTraDuLieu($_POST['password']);
                }
                if (empty($_POST['repassword'])) {
                    $kiemtraFlag = false;
                }
                else {
                    $repassword = kiemTraDuLieu($_POST['repassword']);
                    if ($password != $repassword) {
                        $kiemtraFlag = false;
                    }
                }
                if (!$kiemtraFlag) {
                    header("Location: dangky.html");
                }

                $servername = "localhost";
                $username = "root";
                $passworddb = "";
                $db = "csdlphp";

                $conn = mysqli_connect($servername, $username, $passworddb, $db);

                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                // $insert_query = "INSERT INTO taikhoan(email, password) VALUES('" . $email . "', '" . md5($password) .  "')";
                $insert_query = "INSERT INTO tbltaikhoan(ThuDienTu, MatKhau) VALUES('" . $email . "', '" . $password .  "')";
                if (mysqli_query($conn, $insert_query)) {
                    ?>
                    <div>Bạn đã đăng ký thành công! Hãy bấm vào <a href="dangnhap.php">đây</a> để đăng nhập.</div>
                    <?php
                }
                else {
                    header("Location: abc.html");
                }
                mysqli_close($conn);
            }
        ?>

    <form action="dangky.php" method="POST">
            <input type="text" name="email" placeholder="Hãy nhập vào email"/><br/>
            <input type="password" name="password" placeholder="Hãy nhập vào mật khẩu"/><br/>
            <input type="password" name="repassword" placeholder="Mật khẩu nhập lại"/><br/>
            <input type="submit" value="Đăng ký"/>
        </form>
    </body>
</html>